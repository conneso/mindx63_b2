const exp = require("express");
const router = exp.Router();
const MongoClient = require('mongodb').MongoClient;

//GET api
router.get("/", async (req, res) => {
  const agg = [
    {
      '$lookup': {
        'from': 'users', 
        'localField': 'createdBy', 
        'foreignField': '_id', 
        'as': 'createdByUser'
      }
    }, {
      '$unwind': {
        'path': '$createdByUser'
      }
    }
  ];

  const client = await MongoClient.connect(
    'mongodb+srv://web63:Web63!123@cluster0.cgedwds.mongodb.net/test',
    { useNewUrlParser: true, useUnifiedTopology: true }
  );
  const coll = client.db('web63').collection('orders');
  const cursor = coll.aggregate(agg);
  const result = await cursor.toArray();
  await client.close();

  res.send(result);
});

//GET api
router.get("/:orderId/:custId", (req, res) => {
  const { orderId, custId } = req.params;
  console.log(`orderId: ${orderId}, custId: ${custId}`);
  res.send("get orders by order id and customer id");
});

router.get("/aggregate", async (req, res)=>{
  const agg = [
    {
      '$match': {
        'size': `${req.query.size}`
      }
    }, {
      '$group': {
        '_id': '$name', 
        'totalQuantity': {
          '$sum': '$quantity'
        }, 
        'averageOrderPrice': {
          '$avg': '$price'
        }
      }
    }
  ];

  const client = await MongoClient.connect(
    'mongodb+srv://web63:Web63!123@cluster0.cgedwds.mongodb.net/test',
    { useNewUrlParser: true, useUnifiedTopology: true }
  );
  const coll = client.db('web63').collection('orders');
  const cursor = coll.aggregate(agg);
  const result = await cursor.toArray();
  await client.close();

  res.send(result);
})

module.exports = router